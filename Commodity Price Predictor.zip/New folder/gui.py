import os
import tkinter as tk
from tkinter import ttk, messagebox
from dotenv import load_dotenv
import requests
from datetime import datetime, timedelta
import csv

try:
    from sklearn.linear_model import LinearRegression
    import numpy as np
    from statsmodels.tsa.arima.model import ARIMA
except ImportError:
    LinearRegression = None

load_dotenv()
API_KEY = os.getenv("API_KEY")

commodities = {
    "Gold": "gold",
    "Silver": "silver",
    "Copper": "copper",
    "Platinum": "platinum",
    "Palladium": "palladium"
}

def get_historical_prices(commodity):
    csv_path = os.path.join("data", f"{commodity}.csv")
    prices = []
    if os.path.isfile(csv_path):
        with open(csv_path, newline="") as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                try:
                    price = float(row["price"])
                    if price > 0:
                        prices.append(price)
                except Exception:
                    continue
    return prices

def fetch_current_price(commodity):
    url = f"https://api.api-ninjas.com/v1/commodityprice?name={commodity}"
    headers = {"X-Api-Key": API_KEY}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code != 200:
            return None
        data = response.json()
        if not isinstance(data, dict) or "price" not in data:
            return None
        return data["price"]
    except Exception:
        return None

def moving_average(prices, window=7):
    if len(prices) < window:
        return sum(prices) / len(prices)
    return sum(prices[-window:]) / window

def linear_regression_predict(prices, days_ahead):
    if LinearRegression is None or len(prices) < 2:
        return None
    X = np.arange(len(prices)).reshape(-1, 1)
    y = np.array(prices)
    model = LinearRegression().fit(X, y)
    future_day = np.array([[len(prices) + days_ahead - 1]])
    return float(model.predict(future_day)[0])

def arima_predict(prices, days_ahead):
    if len(prices) < 10:
        return None  # ARIMA needs at least 10 data points for stability
    model = ARIMA(prices, order=(1,1,1))
    model_fit = model.fit()
    forecast = model_fit.forecast(steps=days_ahead)
    return float(forecast[-1])

def predict():
    commodity_name = commodity_var.get()
    days = days_var.get()
    if not commodity_name or not days.isdigit() or int(days) < 1:
        messagebox.showerror("Input Error", "Please select a commodity and enter a valid number of days.")
        return
    commodity = commodities[commodity_name]
    days_ahead = int(days)
    prediction_date = datetime.now() + timedelta(days=days_ahead)
    historical_prices = get_historical_prices(commodity)
    if len(historical_prices) >= 10:
        predicted_price = arima_predict(historical_prices, days_ahead)
        current_price = historical_prices[-1]
    elif len(historical_prices) >= 2 and LinearRegression is not None:
        predicted_price = linear_regression_predict(historical_prices, days_ahead)
        current_price = historical_prices[-1]
    elif historical_prices:
        predicted_price = moving_average(historical_prices)
        current_price = historical_prices[-1]
    else:
        current_price = fetch_current_price(commodity)
        if current_price is None:
            messagebox.showerror("API Error", "Could not fetch price for this commodity.")
            return
        predicted_price = current_price
    result = (
        f"Commodity: {commodity_name}\n"
        f"Current Price: ${current_price:,.2f}\n"
        f"Expected Price (in {days_ahead} day(s)): ${predicted_price:,.2f}\n"
        f"Prediction Date: {prediction_date.date()}"
    )
    result_var.set(result)

# GUI setup
root = tk.Tk()
root.title("Commodity Price Predictor")

mainframe = ttk.Frame(root, padding="10")
mainframe.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

ttk.Label(mainframe, text="Select Commodity:").grid(row=0, column=0, sticky=tk.W)
commodity_var = tk.StringVar()
commodity_menu = ttk.Combobox(mainframe, textvariable=commodity_var, values=list(commodities.keys()), state="readonly")
commodity_menu.grid(row=0, column=1, sticky=tk.W)

ttk.Label(mainframe, text="Days Ahead:").grid(row=1, column=0, sticky=tk.W)
days_var = tk.StringVar()
days_entry = ttk.Entry(mainframe, textvariable=days_var, width=5)
days_entry.grid(row=1, column=1, sticky=tk.W)

predict_btn = ttk.Button(mainframe, text="Predict", command=predict)
predict_btn.grid(row=2, column=0, columnspan=2, pady=10)

result_var = tk.StringVar()
result_label = ttk.Label(mainframe, textvariable=result_var, justify=tk.LEFT)
result_label.grid(row=3, column=0, columnspan=2, sticky=tk.W)

root.mainloop()