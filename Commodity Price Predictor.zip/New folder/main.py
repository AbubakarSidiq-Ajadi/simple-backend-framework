import os
import requests
from dotenv import load_dotenv
from datetime import datetime, timedelta
import csv

try:
    from sklearn.linear_model import LinearRegression
    import numpy as np
except ImportError:
    LinearRegression = None

try:
    from statsmodels.tsa.arima.model import ARIMA
except ImportError:
    ARIMA = None

# --- 1. Load environment variables ---
load_dotenv()
API_KEY = os.getenv("API_KEY")

# --- 2. Commodities dictionary ---
commodities = {
    "1": "gold",
    "2": "silver",
    "3": "copper",
    "4": "platinum",
    "5": "palladium"
}

def get_historical_prices(commodity):
    csv_path = os.path.join("data", f"{commodity}.csv")
    prices = []
    if os.path.isfile(csv_path):
        with open(csv_path, newline="") as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                try:
                    price = float(row["price"])
                    if price > 0:
                        prices.append(price)
                except Exception:
                    continue
    return prices

def fetch_current_price(commodity):
    url = f"https://api.api-ninjas.com/v1/commodityprice?name={commodity}"
    headers = {"X-Api-Key": API_KEY}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        if response.status_code != 200:
            print("❌ API error:", response.text)
            return None
        data = response.json()
        if not isinstance(data, dict) or "price" not in data:
            print("❌ API returned invalid data.")
            return None
        return data["price"]
    except Exception as e:
        print("❌ API request failed:", e)
        return None

def moving_average(prices, window=7):
    if len(prices) < window:
        return sum(prices) / len(prices)
    return sum(prices[-window:]) / window

def linear_regression_predict(prices, days_ahead):
    if LinearRegression is None or len(prices) < 2:
        return None
    X = np.arange(len(prices)).reshape(-1, 1)
    y = np.array(prices)
    model = LinearRegression().fit(X, y)
    future_day = np.array([[len(prices) + days_ahead - 1]])
    return float(model.predict(future_day)[0])

def arima_predict(prices, days_ahead):
    if ARIMA is None or len(prices) < 10:
        return None
    model = ARIMA(prices, order=(1,1,1))
    model_fit = model.fit()
    forecast = model_fit.forecast(steps=days_ahead)
    return float(forecast[-1])

def save_prediction(commodity, prediction_date, predicted_price):
    csv_file = "predictions.csv"
    file_exists = os.path.isfile(csv_file)
    with open(csv_file, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Commodity", "Prediction Date", "Predicted Price"])
        writer.writerow([commodity, prediction_date, round(predicted_price, 2)])

def main():
    print("\n=== Commodity Price Predictor ===")
    print("Available commodities:")
    for key, value in commodities.items():
        print(f"{key}. {value.title()}")
    choice = input("Enter the number of the commodity: ").strip()
    if choice not in commodities:
        print("❌ Invalid choice.")
        return
    selected_commodity = commodities[choice]
    days = input("Enter number of days in the future to predict: ").strip()
    try:
        days_ahead = int(days)
        if days_ahead < 1:
            raise ValueError
    except ValueError:
        print("❌ Invalid number of days. Must be a positive integer.")
        return
    prediction_date = datetime.now() + timedelta(days=days_ahead)
    historical_prices = get_historical_prices(selected_commodity)
    current_price = fetch_current_price(selected_commodity)

    if historical_prices and len(historical_prices) >= 2:
        if len(historical_prices) >= 10 and ARIMA is not None:
            predicted_price = arima_predict(historical_prices, days_ahead)
            current_price = historical_prices[-1]
        elif len(historical_prices) >= 2 and LinearRegression is not None:
            predicted_price = linear_regression_predict(historical_prices, days_ahead)
            current_price = historical_prices[-1]
        elif historical_prices:
            predicted_price = moving_average(historical_prices)
            current_price = historical_prices[-1]
        else:
            if current_price is None:
                print("Prediction failed.")
                return
            predicted_price = current_price
    else:
        if current_price is None:
            print("❌ Could not fetch price for this commodity.")
            return
        predicted_price = current_price

    save_prediction(selected_commodity, prediction_date.date(), predicted_price)

    print("\n🔎 Prediction Summary")
    print(f"Commodity: {selected_commodity.title()}")
    print(f"Current Price: ${current_price:,.2f}")
    print(f"Expected Price (in {days_ahead} day(s)): ${predicted_price:,.2f}")
    print(f"Prediction Date: {prediction_date.date()}")
    print("Prediction saved to predictions.csv")

if __name__ == "__main__":
    main()