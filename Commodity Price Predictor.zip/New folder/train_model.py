import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle
from datetime import datetime
import os

def date_to_day_number(dates):
    base = datetime.strptime(dates[0], "%Y-%m-%d")
    return [(datetime.strptime(d, "%Y-%m-%d") - base).days for d in dates]

def train_and_save_model(csv_path, model_path):
    # Load CSV
    df = pd.read_csv(csv_path)
    if 'date' not in df.columns or 'price' not in df.columns:
        print("CSV must have 'date' and 'price' columns.")
        return

    df = df.dropna()
    df['days'] = date_to_day_number(df['date'].tolist())

    X = df[['days']]
    y = df['price']

    model = LinearRegression()
    model.fit(X, y)

    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)

    print(f"✅ Model trained and saved to {model_path}")

if __name__ == "__main__":
    csv_path = "data/gold.csv"
    model_path = "models/gold_model.pkl"
    train_and_save_model(csv_path, model_path)