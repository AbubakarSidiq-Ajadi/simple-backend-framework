# Commodity Price Predictor

A Python application for predicting future prices of commodities (Gold, Silver, Copper, Platinum, Palladium) using historical data and statistical models (ARIMA, Linear Regression, Moving Average).  
Supports both Command-Line Interface (CLI) and Graphical User Interface (GUI).

---

## Features

- **Predicts future commodity prices** using ARIMA (if enough data), Linear Regression, or Moving Average.
- **Loads historical price data** from CSV files.
- **Fetches current prices** from the [API Ninjas Commodity Price API](https://api-ninjas.com/api/commodityprice).
- **Saves predictions** to a CSV file for future reference.
- **Logs predictions and errors** to a log file.
- **Supports both CLI and GUI** (Tkinter) interfaces.
- **Secure API key management** using a `.env` file.

---

## Requirements

- Python 3.8+
- [API Ninjas](https://api-ninjas.com/) API key (free for gold, paid for others)
- The following Python packages:
  - `python-dotenv`
  - `requests`
  - `scikit-learn`
  - `numpy`
  - `statsmodels`
  - `tkinter` (usually included with Python)
  - `matplotlib` (optional, for plotting in CLI)

**Install all dependencies:**
```sh
pip install python-dotenv requests scikit-learn numpy statsmodels matplotlib
```

---

## Setup

1. **Clone this repository** and navigate to the project folder.

2. **Create a `.env` file** in the project root:
    ```
    API_KEY=your_actual_api_key_here
    ```

3. **Prepare historical data:**
    - Place CSV files (e.g., `gold.csv`, `silver.csv`, etc.) in a `data/` folder.
    - Each CSV should have the format:
      ```
      date,price
      2024-05-20,2415.10
      2024-05-21,2420.30
      ...
      ```

---

## Usage

### **Command-Line Interface (CLI)**

Run:
```sh
python main.py
```
- Follow the prompts to select a commodity and prediction horizon.
- Predictions are saved to `predictions.csv`.

### **Graphical User Interface (GUI)**

Run:
```sh
python gui.py
```
- Use the dropdown and entry fields to select a commodity and days ahead.
- The prediction will be displayed in the window.

---

## How It Works

- **Prediction order:**  
  - If 10+ historical prices: uses ARIMA.
  - Else if 2+ prices: uses Linear Regression.
  - Else: uses Moving Average or current API price.
- **All predictions and errors are logged** in `app.log`.
- **Predictions are saved** in `predictions.csv` for future reference.

---

## Example

```
=== Commodity Price Predictor ===
Available commodities:
1. Gold
2. Silver
3. Copper
4. Platinum
5. Palladium
Enter the number of the commodity: 1
Enter number of days in the future to predict: 3

🔎 Prediction Summary
Commodity: Gold
Current Price: $2448.50
Expected Price (in 3 day(s)): $2455.12
Prediction Date: 2025-06-03
Prediction saved to predictions.csv
```

---

## Security

- **Never share your `.env` file or API key.**
- Add `.env` to your `.gitignore` if using version control.

---

## License

This project is for educational and demonstration purposes.
