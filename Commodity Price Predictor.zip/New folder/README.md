# Commodity Price Predictor

A Python CLI tool that predicts future prices of global commodities using real-time data from API Ninja.

## 🔧 Features

- Fetches real-time prices of Gold, Silver, Copper, etc.
- Predicts future prices with estimated accuracy
- User selects commodity and target day

## 📦 Setup

1. Install dependencies: pip install -r requirements.txt